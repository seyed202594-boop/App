package com.kadooblue

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.launch

private val Context.dataStore by preferencesDataStore(name = "kadooblue_prefs")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KadooBlueApp()
        }
    }
}

@Composable
fun KadooBlueApp() {
    val categories = listOf(
        "لوگو","پوستر","طراحی اپلیکیشن","کاراکتر","بسته‌بندی",
        "تایپوگرافی","قاب تصویر","کارت ویزیت","کمپین تبلیغاتی","موشن گرافیک"
    )

    val constraints = listOf(
        "پالت رنگ ۲ رنگ","بدون عکس واقعی","فونت نستعلیق‌وار",
        "در کمتر از ۳۰ دقیقه","تنها اشکال هندسی","مناسب کودکان",
        "محوریت طبیعت","سبک مینیمال","الهام از معماری ایرانی",
        "تاکید بر حرف اول اسم"
    )

    val twists = listOf(
        "با محدودیت پالت","با یک المان تکرارشونده","بدون متن","تاکید بر نور و سایه",
        "استفاده از یک شکل هندسی بزرگ"
    )

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var currentChallenge by remember { mutableStateOf("") }
    var customInput by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(listOf<String>()) }

    // load history (simple)
    LaunchedEffect(Unit) {
        val key = stringSetPreferencesKey("history_set")
        context.dataStore.data.collect { prefs ->
            val set = prefs[key] ?: emptySet()
            history = set.toList().reversed()
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("کدو بلو", fontWeight = FontWeight.Bold) },
                    backgroundColor = androidx.compose.ui.graphics.Color(0xFF8E44AD),
                    contentColor = androidx.compose.ui.graphics.Color.White)
            }
        ) { padding ->
            Column(modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)) {

                Text("چالش طراحی جدید", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = customInput,
                    onValueChange = { customInput = it },
                    label = { Text("موضوع دلخواه (اختیاری)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                val scale = remember { Animatable(1f) }
                val coroutine = rememberCoroutineScope()
                Button(
                    onClick = {
                        coroutine.launch {
                            scale.animateTo(1.06f, tween(120))
                            scale.animateTo(1f, tween(180))
                        }
                        val generated = if (customInput.isNotBlank()) {
                            "طراحی (${customInput.trim()}) — شرایط: ${randomConstraints(constraints)} — زمان: ${randomTime()} — چرخش: ${twists.random()}"
                        } else {
                            val cat = categories.random()
                            "طراحی $cat — شرایط: ${randomConstraints(constraints)} — زمان: ${randomTime()} — چرخش: ${twists.random()}"
                        }
                        currentChallenge = generated
                        history = listOf(generated) + history
                        coroutineScope.launch {
                            saveHistory(context, history)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .scale(scale.value)
                ) {
                    Text("تپ کن — ایجاد چالش", fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (currentChallenge.isNotEmpty()) {
                    Card(elevation = 6.dp, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("چالش فعلی:", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(currentChallenge)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { shareText(context, currentChallenge) }) {
                                    Icon(Icons.Default.Share, contentDescription = "اشتراک")
                                }
                                TextButton(onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    val clip = android.content.ClipData.newPlainText("KadooBlue Challenge", currentChallenge)
                                    clipboard.setPrimaryClip(clip)
                                }) {
                                    Text("کپی")
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text("سابقهٔ چالش‌ها", fontWeight = FontWeight.Medium)
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    items(history) { item ->
                        Card(modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp), elevation = 2.dp) {
                            Row(modifier = Modifier
                                .padding(10.dp)
                                .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = item)
                                }
                                IconButton(onClick = { shareText(context, item) }) {
                                    Icon(Icons.Default.Share, contentDescription = "اشتراک")
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.weight(1f))
                Text("نسخهٔ نهایی کدو بلو", fontSize = 12.sp)
            }
        }
    }
}

private fun randomConstraints(constraints: List<String>): String {
    val selected = mutableSetOf<String>()
    while (selected.size < 2) selected.add(constraints.random())
    return selected.joinToString("، ")
}
private fun randomTime(): String {
    return listOf("15 دقیقه", "30 دقیقه", "1 ساعت", "2 ساعت").random()
}

private suspend fun saveHistory(context: Context, items: List<String>) {
    val key = stringSetPreferencesKey("history_set")
    val set = items.toSet()
    context.dataStore.edit { prefs ->
        prefs[key] = set
    }
}

private fun shareText(context: Context, text: String) {
    val intent = Intent(Intent.ACTION_SEND)
    intent.type = "text/plain"
    intent.putExtra(Intent.EXTRA_SUBJECT, "چالش طراحی از کدو بلو")
    intent.putExtra(Intent.EXTRA_TEXT, text)
    context.startActivity(Intent.createChooser(intent, "اشتراک با"))
}
