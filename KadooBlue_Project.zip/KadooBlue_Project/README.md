پروژهٔ 'Kadoo Blue' - نسخهٔ نهایی (APK)
----------------------------------------

این پروژه آمادهٔ اندروید شامل:
- تولید چالش تصادفی و ورودی موضوع دلخواه
- تم بنفش و آیکون اختصاصی (placeholder)
- افکت/انیمیشن هنگام ایجاد چالش
- سابقهٔ چالش‌ها و اشتراک‌گذاری
- رابط کاربری فارسی (راست‌چین در متن‌ها)

برای ساخت APK بدون Android Studio می‌توانید از سرویس‌های آنلاین CI/CD مانند:
- codemagic.io
- bitrise.io
یا از command-line (Gradle) در یک ماشین با JDK و Android SDK نصب‌شده:
./gradlew assembleDebug

فایل APK نهایی پس از ساخت در:
app/build/outputs/apk/debug/app-debug.apk
